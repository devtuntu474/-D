const settings = require('../settings');
const os = require("os");
const fs = require('fs');
const path = require('path');

// Function to format uptime
function getUptimeFormatted() {
    const totalSeconds = process.uptime();
    const days = Math.floor(totalSeconds / (3600 * 24));
    const hours = Math.floor((totalSeconds % (3600 * 24)) / 3600);
    const minutes = Math.floor((totalSeconds % 3600) / 60);
    const seconds = Math.floor(totalSeconds % 60);
    return `${days}d ${hours}h ${minutes}m ${seconds}s`;
}

async function helpCommand(sock, chatId, message) {
    const uptimeFormatted = getUptimeFormatted(); // Calculate uptime
    const helpMessage = `
╭━━━☬ℝ𝔼𝔻𝕋𝔼ℂℍ♞𝕏𝕄𝔻♛━━━━┈⊷
┃❍⁠⁠╭──────────────
┃❍⁠⁠│♕  *Usᴇʀ* : ${settings.botOwner}
┃❍⁠⁠│♕  *ʙᴀɪʟᴇʏs* : 𝐌𝐮𝐥𝐭𝐢 𝐝𝐞𝐯𝐢𝐜𝐞
┃❍⁠⁠│♕  *𝖳ʏᴘᴇ* : 𝐍𝐨𝐝𝐞𝐣𝐬
┃❍⁠⁠│♕  *RunTime* : ${uptimeFormatted}
┃❍⁠⁠│♕  *ᴘʟᴀᴛғᴏʀᴍ* : ${os.hostname()}
┃❍⁠⁠│♕  *ᴏᴡɴᴇʀ ɴᴜᴍʙᴇʀ* : ${settings.ownerNumber}
┃❍⁠⁠│♕  *ᴍᴏᴅᴇ* : [ . ]
┃❍⁠⁠│♕  *ᴄᴏᴍᴍᴀɴᴅs* : 147
┃❍⁠⁠│♕  *𝖣ᴇᴠᴇʟᴏᴘᴇʀ* : 𝔻𝔼𝕍 𝕋𝕌ℕ𝕋𝕌 ℝ𝔼𝔻
┃❍⁠⁠│♕  *Dev Number* : +255742852285
┃❍⁠⁠│♕  *Assintant Dev* : ℕ𝕆ℕ𝔼
┃❍⁠⁠│♕  *Assintant Dev Number* : +255747196463
┃❍⁠⁠│♕  *𝖵ᴇʀsɪᴏɴ* : ${settings.version}
┃❍⁠⁠╰───────────♛♛♛
╰━━━━━━━━━━━━━━━━━✯✯✯
   ☸𝐀𝐯𝐚𝐢𝐥𝐥𝐚𝐛𝐥𝐞 𝐜𝐨𝐦𝐦𝐚𝐧𝐝𝐬☸
╭━━━━━━━━━━━━━━━✯✯✯
┃  ♡𝙶𝙴𝙽𝙴𝚁𝙰𝙻 𝙲𝙾𝙼𝙼𝙰𝙽𝙳𝚂♡
║ ♘ 𝚑𝚎𝚕𝚙
║ ♘ 𝚖𝚎𝚗𝚞
║ ♘ 𝚙𝚒𝚗𝚐
║ ♘ 𝚊𝚕𝚒𝚟𝚎
║ ♘ 𝚝𝚝𝚜 <text>
║ ♘ 𝚘𝚠𝚗𝚎𝚛
║ ♘ 𝚓𝚘𝚔𝚎
║ ♘ 𝚚𝚞𝚘𝚝𝚎
║ ♘ 𝚏𝚊𝚌𝚝
║ ♘ 𝚠𝚎𝚊𝚝𝚑𝚎𝚛 <city>
║ ♘ 𝚗𝚎𝚠𝚜
║ ♘ 𝚊𝚝𝚝𝚙 <text>
║ ♘ 𝚕𝚢𝚛𝚒𝚌𝚜 <song_title>
║ ♘ 8𝚋𝚊𝚕𝚕 <question>
║ ♘ 𝚐𝚛𝚘𝚞𝚙𝚒𝚗𝚏𝚘
║ ♘ staff or .admins 
║ ♘ 𝚟𝚟
║ ♘ 𝚝𝚛𝚝 <text> <lang>
║ ♘ 𝚓𝚒𝚍
╰━━━━━━━━━━━━━━━✫✫✫
╭━━━━━━━━━━━━━━━☆☆☆
┃ ♡𝙰𝙳𝙼𝙸𝙽 𝙲𝙾𝙼𝙼𝙰𝙽𝙳𝚂♡
║ • 𝚋𝚊𝚗 @user
║ • 𝚙𝚛𝚘𝚖𝚘𝚝𝚎 @user
║ • 𝚍𝚎𝚖𝚘𝚝𝚎 @user
║ • 𝚖𝚞𝚝𝚎 <minutes>
║ • 𝚞𝚗𝚖𝚞𝚝𝚎
║ • 𝚍𝚎𝚕𝚎𝚝𝚎 or .del
║ • 𝚔𝚒𝚌𝚔 @user
║ • 𝚠𝚊𝚛𝚗𝚒𝚗𝚐𝚜 @user
║ • 𝚠𝚊𝚛𝚗 @user
║ • 𝚊𝚗𝚝𝚒𝚕𝚒𝚗𝚔 𝚘𝚗
║ • 𝚊𝚗𝚝𝚒𝚕𝚒𝚗𝚔 set delete
║ • 𝚊𝚗𝚝𝚒𝚕𝚒𝚗𝚔 set warning
║ • 𝚊𝚗𝚝𝚒𝚕𝚒𝚗𝚔 set kick
║ • 𝚊𝚗𝚝𝚒𝚋𝚊𝚍𝚠𝚘𝚛𝚍𝚜
║ • 𝚌𝚕𝚎𝚊𝚛
║ • 𝚝𝚊𝚐 <message>
║ • 𝚝𝚊𝚐𝚊𝚕𝚕
║ • 𝚌𝚑𝚊𝚝𝚋𝚘𝚝
║ • 𝚛𝚎𝚜𝚎𝚗𝚝𝚕𝚒𝚗𝚔
║ • 𝚠𝚎𝚕𝚌𝚘𝚖𝚎 <on/off>
║ • 𝚐𝚘𝚘𝚍𝚋𝚢𝚎 <on/off>
╰━━━━━━━━━━━━━━✯✯✯
╭━━━━━━━━━━━━━━✯✯✯
┃ ♡𝙾𝚆𝙽𝙴𝚁 𝙲𝙾𝙼𝙼𝙰𝙽𝙳𝚂♡
║ ♘ 𝙼𝙾𝙳𝙴 𝙿𝚁𝙸𝚅𝙰𝚃𝙴
║ ♘ 𝙼𝙾𝙳𝙴 𝚂𝙴𝙻𝙵
║ ♘ 𝙰𝚄𝚃𝙾𝚂𝚃𝙰𝚃𝚄𝚂
║ ♘ 𝙲𝙻𝙴𝙰𝚁𝚂𝙴𝚂𝚂𝙸𝙾𝙽
║ ♘ 𝙰𝙽𝚃𝙸𝙳𝙴𝙻𝙴𝚃𝙴
║ ♘ 𝙲𝙻𝙴𝙰𝚁𝚃𝙼𝙿
║ ♘ 𝚂𝙴𝚃𝙿𝙿 <reply to image>
║ ♘ 𝙰𝚄𝚃𝙾𝚁𝙴𝙰𝙲𝚃 on
║ ♘ 𝙰𝚄𝚃𝙾𝚁𝙴𝙰𝙲𝚃 off
╰━━━━━━━━━━━━━━━✯✯✯
╭━━━━━━━━━━━━━━━✯✯✯
┃ ♡𝚂𝙲𝚁𝙴𝙴𝙽𝚂𝙷𝙾𝚃 𝚃𝙾𝙾𝙻𝚂♡
║ ♘ 𝙶𝙰𝙻𝙰𝚇𝚈𝚂<link>
║ ♘ 𝚂𝚂 <link>
║ ♘ s𝚂𝚂𝚆𝙴𝙱 <link>
║ ♘ iphone14promax <link>
║ ♘ 𝙸𝙿𝙷𝙾𝙽𝙴 12𝙿𝚁𝙾 <link>
║ ♘ 𝙸𝙿𝙷𝙾𝙽𝚇 <link>
║ ♘ iphone6plus <link>
║ ♘ 𝙸𝙿𝙷𝙾𝙽𝙴6 <link>
║ ♘ 𝙸𝙿𝙷𝙾𝙽𝙴5 <link>
║ ♘ 𝙼𝙰𝚇𝙰𝙶𝙴 <link>
╰━━━━━━━━━━━━━━━✯✯✯
╭━━━━━━━━━━━━━━━✯✯✯
┃ ♡𝙸𝙼𝙰𝙶𝙴/𝚂𝚃𝙸𝙲𝙺𝙴𝚁 𝙲𝙾𝙼𝙼𝙰𝙽𝙳𝚂♡
║ ♘ 𝚋𝚕𝚞𝚛 <image>
║ ♘ 𝚜𝚒𝚖𝚊𝚐𝚎 <reply to sticker>
║ ♘ 𝚜𝚝𝚒𝚌𝚔𝚎𝚛 <reply to image>
║ ♘ 𝚝𝚐𝚜𝚝𝚒𝚌𝚔𝚎𝚛 <Link>
║ ♘ 𝚖𝚎𝚖𝚎
║ ♘ 𝚝𝚊𝚔𝚎 <packname> 
║ ♘ 𝚎𝚖𝚘𝚓𝚒𝚖𝚒𝚡 <emj1>+<emj2>
╰━━━━━━━━━━━━━━━✯✯✯
╭━━━━━━━━━━━━━━━✯✯✯
┃ ♡𝙶𝙰𝙼𝙴 𝙲𝙾𝙼𝙼𝙰𝙽𝙳𝚂♡
║ ❐ tictactoe @user
║ ❐ 𝚑𝚊𝚗𝚐𝚖𝚊𝚗
║ ❐ 𝚐𝚞𝚎𝚜𝚜 <letter>
║ ❐ 𝚝𝚛𝚒𝚟𝚒𝚊
║ ❐ 𝚊𝚗𝚜𝚠𝚎𝚛 <answer>
║ ❐ 𝚝𝚛𝚞𝚝𝚑
║ ❐ 𝚍𝚊𝚛𝚎
╰━━━━━━━━━━━━━━✯✯✯
╭━━━━━━━━━━━━━━✯✯✯
┃ ♡𝙰𝙸 𝙲𝙾𝙼𝙼𝙰𝙽𝙳𝚂♡
║ ❐  𝚐𝚙𝚝 <question>
║ ❐  llama <question>
║ ❐  𝚘𝚙𝚎𝚗𝚊𝚒 <question>
║ ❐  𝚐𝚎𝚖𝚒𝚗𝚒 <question>
║ ❐  𝚖𝚒 <prompt>
║ ❐  𝚒𝚖𝚊𝚐𝚎-𝚐𝚎𝚗𝚎𝚛𝚊𝚝𝚎 <prompt>
║ ❐  𝚒𝚖𝚊𝚐𝚒𝚗𝚎 <prompt>
║ ❐  𝚏𝚕𝚞𝚡 <prompt>
╰━━━━━━━━━━━━━━━✯✯✯
╭━━━━━━━━━━━━━━━✯✯✯
┃ ♡𝙵𝚄𝙽 𝙲𝙾𝙼𝙼𝙰𝙽𝙳𝚂♡
║ ❐ 𝚌𝚘𝚖𝚙𝚕𝚒𝚖𝚎𝚗𝚝 @user
║ ❐ 𝚒𝚗𝚜𝚞𝚕𝚝 @user
║ ❐ 𝚏𝚕𝚒𝚛𝚝
║ ❐ 𝚜𝚑𝚊𝚢𝚊𝚛𝚒
║ ❐ 𝚐𝚘𝚘𝚍𝚗𝚒𝚐𝚑𝚝
║ ❐ 𝚛𝚘𝚜𝚎𝚍𝚊𝚢
║ ❐ 𝚌𝚑𝚊𝚛𝚊𝚌𝚝𝚎𝚛 @user
║ ❐ 𝚠𝚊𝚜𝚝𝚎𝚍 @user
║ ❐ 𝚜𝚑𝚒𝚙 @user
║ ❐ 𝚜𝚒𝚖𝚙 @user
║ ❐ 𝚜𝚝𝚞𝚙𝚒𝚍 @user [text]
╰━━━━━━━━━━━━━━━✯✯✯
╭━━━━━━━━━━━━━━━✯✯✯
┃ ♡𝚃𝙴𝚇𝚃 𝙼𝙰𝙺𝙴𝚁♡
║ ♘ 𝚖𝚎𝚝𝚊𝚕𝚕𝚒𝚌 <text>
║ ♘ 𝚒𝚌𝚎 <text>
║ ♘ 𝚜𝚗𝚘𝚠 <text>
║ ♘ 𝚒𝚖𝚙𝚛𝚎𝚜𝚜i𝚟𝚎 <text>
║ ♘ 𝚖𝚊𝚝𝚛𝚒𝚡 <text>
║ ♘ 𝚕𝚒𝚐𝚑𝚝 <text>
║ ♘ 𝚗𝚎𝚘𝚗 <text>
║ ♘ 𝚍𝚎𝚟𝚒𝚕 <text>
║ ♘ 𝚙𝚞𝚛𝚙𝚕𝚎 <text>
║ ♘ 𝚝𝚑𝚞𝚗𝚍𝚎𝚛 <text>
║ ♘ 𝚕𝚎𝚊𝚟𝚎𝚜 <text>
║ ♘ 1917 <text>
║ ♘ 𝚊𝚛𝚎𝚗𝚊 <text>
║ ♘ 𝚑𝚊𝚌𝚔𝚎𝚛 <text>
║ ♘ 𝚜𝚊𝚗𝚍 <text>
║ ♘ 𝚋𝚕𝚊𝚌𝚔𝚙𝚒𝚗𝚔 <text>
║ ♘ 𝚐𝚕𝚒𝚝𝚌𝚑 <text>
║ ♘ incandescent <text>
║ ♘ 𝚐𝚘𝚕𝚍 <text>
║ ♘ 𝚙𝚞𝚛𝚙𝚕𝚎2 <text>
║ ♘ 𝚗𝚎𝚘𝚗 <text>
║ ♘ 𝚝𝚑𝚘𝚛 <text>
║ ♘ 𝚠𝚑𝚒𝚝𝚎𝚐𝚘𝚕𝚍 <text>
║ ♘ 𝚕𝚒𝚐𝚑𝚝𝚐𝚕𝚘𝚠 <text>
║ ♘ 𝚌𝚊𝚝 <text>
║ ♘ 𝚑𝚊𝚛𝚛𝚢𝚙𝚘𝚝𝚝𝚎𝚛 <text>
║ ♘ 𝚝𝚛𝚊𝚗𝚜𝚏𝚘𝚛𝚖𝚎𝚛 <text>
║ ♘ 𝚜𝚗𝚘𝚠 <text>
║ ♘ 𝚠𝚊𝚝𝚎𝚛 <text>
║ ♘ 𝚍𝚎𝚟𝚒𝚕2 <text>
║ ♘ 𝚗𝚎𝚘𝚗𝚕𝚒𝚐𝚑𝚝 <text>
║ ♘ 𝚐𝚛𝚎𝚎𝚗𝚗𝚎𝚘𝚗 <text>
║ ♘ 𝚏𝚒𝚛𝚎 <text>
║ ♘ 𝚠𝚊𝚕𝚕 <text>
║ ♘ 𝚑𝚊𝚌𝚔𝚎𝚛 <text>
║ ♘ 𝚗𝚊𝚛𝚞𝚝𝚘 <text>
║ ♘ 𝚍𝚒𝚍𝚘𝚗𝚐 <text>
║ ♘ 𝚍𝚛𝚊𝚐𝚘𝚗𝚋𝚊𝚕𝚕 <text>
╰━━━━━━━━━━━━━━✯✯✯
╭━━━━━━━━━━━━━━✯✯✯
┃ *𝙳𝙾𝚆𝙻𝙾𝙰𝙳𝙸𝙽𝙶 𝙼𝙴𝙽𝚄*:
║ • 𝚙𝚕𝚊𝚢 <song_name>
║ • 𝚜𝚘𝚗𝚐 <song_name>
║ • 𝚒𝚗𝚜𝚝𝚊𝚐𝚛𝚊𝚖 or ig <link>
║ • 𝚏𝚊𝚌𝚎𝚋𝚘𝚘𝚔 or fb <link>
║ • 𝚝𝚒𝚔𝚝𝚘𝚔 or tt <link>
║ • 𝚟𝚒𝚍𝚎𝚘 <song name>
║ • 𝚢𝚝𝚖𝚙4 <Link>
║ • 𝚜𝚑𝚊𝚣𝚊𝚖 @TagAudio
║ • 𝚜𝚑 @TagAudio
╰━━━━━━━━━━━━━━━✯✯✯
╭━━━━━━━━━━━━━━━✯✯✯
┃ *𝔾𝕀𝕋ℍ𝕌𝔹 ℂ𝕆𝕄𝕄𝔸ℕ𝔻𝕊: 6*
║ • 𝚐𝚒𝚝彡彡
║ • 𝚐𝚒𝚝𝚑𝚞𝚋彡彡
║ • 𝚜𝚌彡彡
║ • 𝚜𝚌𝚛𝚒𝚙𝚝彡彡
║ • 𝚛𝚎𝚙𝚘彡彡
║ • tgs <Link>彡彡
╰━━━━━━━━━━━━━━━༆༄༆

╭━━━━━━━━━━━━━━━༆༄༆
♕✠✠ 𝐓𝐇𝐈𝐒 𝐁𝐎𝐓 𝐈𝐒 𝐂𝐑𝐄𝐀𝐓𝐄𝐃 𝐁𝐘 𝐓𝐇𝐄 𝐃𝐄𝐕 𝐓𝐔𝐍𝐓𝐔 *𝐑𝐄𝐃𝐓𝐄𝐂𝐇* 
♛☏𝐂𝐎𝐍𝐓𝐀𝐂𝐓 255747196463  ✆
♛☬𝐂𝐎𝐍𝐓𝐀𝐂𝐓 255742852285 ✆✆
╰━━━━━━━━━━━━━━━༆༄༆

> ʀᴇɢᴀʀᴅs ℝ𝔼𝔻𝕋𝔼ℂℍ 𝕏𝔻
> ʀᴇɢᴀʀᴅs 𝑅𝐸𝐷𝑇𝐸𝐶𝐻𝐷𝐸𝑉`;

    try {
        const imagePath = path.join(__dirname, '../asserts/bot_image.jpg');
        const audioUrl = "https://files.catbox.moe/a3y5j2.mp3"; // put your audio mp3 link here by caseyrhodes 

        if (fs.existsSync(imagePath)) {
            const imageBuffer = fs.readFileSync(imagePath);

            await sock.sendMessage(chatId, {
                image: imageBuffer,
                caption: helpMessage,
                contextInfo: {
                    forwardingScore: 1,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: '120363419447259737@newsletter',
                        newsletterName: 'REDTECH XMD',
                        serverMessageId: -1
                    }
                }
            }, { quoted: message });
        } else {
            console.error('Bot image not found at:', imagePath);
            await sock.sendMessage(chatId, {
                text: helpMessage,
                contextInfo: {
                    forwardingScore: 1,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: '120363419447259737@newsletter',
                        newsletterName: 'POWERED BY 𝑅𝐸𝐷𝑇𝐸𝐶𝐻 𝑋𝑀𝐷',
                        serverMessageId: -1
                    }
                }
            }, { quoted: message });
        }

        // 🔊 Send audio message after menu
        await sock.sendMessage(chatId, {
            audio: { url: audioUrl },
            mimetype: 'audio/mpeg',
            ptt: true
        }, { quoted: message });

    } catch (error) {
        console.error('Error in help command:', error);
        await sock.sendMessage(chatId, { text: helpMessage });
    }
}

module.exports = helpCommand;

//msee iko hivi don't edit just add url mp3 there you are done fitty bro made by 𝐷𝐸𝑉𝑇𝑈𝑁𝑇𝑈\\