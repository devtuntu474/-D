const settings = {
  packname: 'ℝ𝔼𝔻𝕋𝔼ℂℍ 𝕏𝕄𝔻',
  author: '‎',
  botName: "ℝ𝔼𝔻𝕋𝔼ℂℍ 𝕏𝕄𝔻",
  botOwner: '255 𝔻𝔼𝕍 𝕋𝕌ℕ𝕋𝕌 ℝ𝔼𝔻 𝕏𝕄𝔽', // Your name
  ownerNumber: '255747196463', //Set your number here without + symbol, just add country code & number without any space
  giphyApiKey: 'qnl7ssQChTdPjsKta2Ax2LMaGXz303tq',
  commandMode: "public",
  prefix: ".",
// add your prifix for bot   
  description: "This is a bot for managing group commands and automating tasks.",
  version: "2.0.2",
};

module.exports = settings;
